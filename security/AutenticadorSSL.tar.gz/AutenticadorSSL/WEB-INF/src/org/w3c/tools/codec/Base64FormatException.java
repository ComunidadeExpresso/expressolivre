package org.w3c.tools.codec;

// Base64FormatException.java
// $Id: Base64FormatException.java,v 1.1 2007/01/22 16:29:35 egonrp Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

// Base64FormatException.java
// $Id: Base64FormatException.java,v 1.1 2007/01/22 16:29:35 egonrp Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

/**
 * Exception for invalid BASE64 streams.
 */

public class Base64FormatException extends Exception {

  /**
   * Create that kind of exception
   * @param msg The associated error message 
   */
  
  public Base64FormatException(String msg) {
	super(msg) ;
  }  
}
