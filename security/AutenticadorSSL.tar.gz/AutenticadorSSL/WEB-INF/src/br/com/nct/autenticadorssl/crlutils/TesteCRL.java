package br.com.nct.autenticadorssl.crlutils;

public class TesteCRL {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		try{
			
			System.out.println("Validando...");
			
			br.com.nct.autenticadorssl.crlutils.CRLManager.validarCertificado(null);

			//br.com.nct.autenticadorssl.crlutils.CRLManager.startUpdateTask(".", 20);
			//Thread.sleep(36000);
			//br.com.nct.autenticadorssl.crlutils.CRLManager.stopUpdateTask();

			System.out.println("OK!!!");
			System.exit(0);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
