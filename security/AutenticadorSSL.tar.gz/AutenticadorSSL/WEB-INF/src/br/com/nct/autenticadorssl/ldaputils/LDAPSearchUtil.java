package br.com.nct.autenticadorssl.ldaputils;

import java.util.Enumeration;
import java.util.HashMap;

import netscape.ldap.LDAPAttribute;
import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPEntry;
import netscape.ldap.LDAPException;
import netscape.ldap.LDAPSearchResults;
import netscape.ldap.LDAPv2;

/**
 * Pesquisa LDAP.
 * @author Egon
 *
 */
public class LDAPSearchUtil {

	
	public static final String CAMPO_USUARIO = "uid";
	public static final String CAMPO_SENHA = "cryptpassword";
	public static final String CAMPO_CERTIFICADO = "userCertificate";
	
	private LDAPSearchUtil() {
	}
	
	
	/**
	 * @param ld
	 * @param dadosUsuarioRet
	 * @param cpf
	 * @throws LDAPException 
	 */
	public static HashMap getDadosUsuario(LDAPConnection ld, String searchBaseDN, String searchFilter, String cpf) throws LDAPException{
		
		HashMap dadosUsuarioRet = new HashMap();
		searchFilter = "(&(" + searchFilter + cpf + "))";
		String[] attrs = {CAMPO_USUARIO, CAMPO_SENHA, CAMPO_CERTIFICADO};
		//base dc=serpro,dc=gov,dc=br
		//filtro (objectclass=*)     ou  (objectclass=posixaccount)

		//debug
		System.out.println("Buscando dados do Diretorio: " + ld.getHost() + " -> BaseDN: " + searchBaseDN + " Filter: " + searchFilter);
		
		//executa query
		LDAPSearchResults results = ld.search(searchBaseDN, LDAPv2.SCOPE_SUB, searchFilter, attrs, false);
		LDAPEntry entry;
	     
	     if(results.hasMoreElements()){
	    	 entry = results.next();
	     }else{
	    	return null;
	     }
	     
		//debug
		printEntry(entry, attrs);
		
		//passa para a hashmap o retorno
		LDAPAttribute attr;
		Enumeration enumVals;
		
		//debug
		//System.out.println("--------- Atributos ----------");
		//LDAPAttributeSet listaAttr =  entry.getAttributeSet();
		//for (int i = 0; i < listaAttr.size(); i++) {
		//	attr = listaAttr.elementAt(i);
		//	System.out.println("Attributo: " + attr.getName());
		//	System.out.println("SubTypes: " + attr.getSubtypes());
		//}
		//System.out.println("--------- FIM Atributos ----------");
		
		
		for (int i=0; i < attrs.length; i++) {
			
			attr = entry.getAttribute(attrs[i]);
			
			System.out.println("Lendo atributo: " + attrs[i]);

			if (attr != null) {
				
				//certificado - binario
				if(attrs[i].equals(CAMPO_CERTIFICADO)){

					enumVals = attr.getByteValues();
					if(enumVals != null && enumVals.hasMoreElements()){
						
						dadosUsuarioRet.put(attrs[i], enumVals.nextElement());
					}
					
				}else{
					
					enumVals = attr.getStringValues();

					if(enumVals != null && enumVals.hasMoreElements()){
						dadosUsuarioRet.put(attrs[i], enumVals.nextElement());
					}
				}
				
			}else{
				System.out.println("Atributo ausente: " + attrs[i]);
			}
		}
	  
		return !dadosUsuarioRet.isEmpty() ? dadosUsuarioRet : null;
	}

	
	
	/**
	 * @param ld
	 * @param dadosUsuarioRet
	 * @param cpf
	 * @throws LDAPException 
	 */
	private static HashMap getDadosUsuarioOld(LDAPConnection ld, String searchDNCpf, String cpf) throws LDAPException{
		
		HashMap dadosUsuarioRet = new HashMap();
		
		String[] attrs = {CAMPO_USUARIO, CAMPO_SENHA, CAMPO_CERTIFICADO};//{"cn", "mail", "telephonenumber"};
		
		//nao funciona desta maneira
		//String dn = searchDNCpf + cpf;//"uid=dsmith, ou=People, o=airius.com";
		
		//assim funciona
		String dn = "uid=" + cpf + ", " +searchDNCpf;
		
		
		//debug
		System.out.println("Buscando dados do Diretorio: " + ld.getHost() + " -> " + dn);
		
		
		//executa query
		LDAPEntry entry = ld.read(dn, attrs);
		
		//debug
		printEntry(entry, attrs);
		
		//passa para a hashmap o retorno
		LDAPAttribute attr;
		Enumeration enumVals;
		
		//debug
		//System.out.println("--------- Atributos ----------");
		//LDAPAttributeSet listaAttr =  entry.getAttributeSet();
		//for (int i = 0; i < listaAttr.size(); i++) {
		//	attr = listaAttr.elementAt(i);
		//	System.out.println("Attributo: " + attr.getName());
		//	System.out.println("SubTypes: " + attr.getSubtypes());
		//}
		//System.out.println("--------- FIM Atributos ----------");
		
		
		for (int i=0; i < attrs.length; i++) {
			
			attr = entry.getAttribute(attrs[i]);
			
			System.out.println("Lendo atributo: " + attrs[i]);

			if (attr != null) {
				
				//certificado - binario
				if(attrs[i].equals(CAMPO_CERTIFICADO)){

					enumVals = attr.getByteValues();
					if(enumVals != null && enumVals.hasMoreElements()){
						
						dadosUsuarioRet.put(attrs[i], enumVals.nextElement());
					}
					
				}else{
					
					enumVals = attr.getStringValues();

					if(enumVals != null && enumVals.hasMoreElements()){
						dadosUsuarioRet.put(attrs[i], enumVals.nextElement());
					}
				}
				
			}else{
				System.out.println("Atributo ausente: " + attrs[i]);
			}
		}
	  
		return !dadosUsuarioRet.isEmpty() ? dadosUsuarioRet : null;
	}

	
    /**
     * Method used to print the names and values of attributes of an entry.
     * 
     * @param entry The entry that contains the attributes
     * @param attrs An array of attribute names to display
     */
    public static void printEntry(LDAPEntry entry, String[] attrs) {
    
        System.out.println("DN: " + entry.getDN());

        // Now, use the array to look through the attributes. It would also
        // have been possible to enumerate the attributes using getAttributes(),
        // but by passing them in this way, we have control of the display 
        // order. After printing all of the attributes using this method, I will
        // also provide a section below on how to enumerate the attributes using
        // the getAttributes() method.
        
        LDAPAttribute attr;
        Enumeration enumVals;
        boolean hasVals;
        String val;
        
        for (int i=0; i < attrs.length; i++) {
            attr = entry.getAttribute(attrs[i]);
            if (attr == null) {
                System.out.println("  [" + attrs[i] + ": nao estah presente]");
                continue;
            }

            enumVals = attr.getStringValues();
            hasVals = false;
            while ( (enumVals != null) && (enumVals.hasMoreElements()) ) {
                val = (String) enumVals.nextElement();
                System.out.println("  [" + attrs[i] + ": " + val + "]");
                hasVals = true;
            }
            if (!hasVals) {
                System.out.println("  [" + attrs[i] + ": nao tem valores]");
            }
        }

        System.out.println("---------------------------------------------------");
    }
}
