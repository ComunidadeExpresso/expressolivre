package br.com.nct.autenticadorssl.crlutils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.zip.CRC32;

import org.bouncycastle.jce.provider.JDKX509CertificateFactory;
import org.bouncycastle.jce.provider.X509CRLEntryObject;
import org.bouncycastle.jce.provider.X509CRLObject;

/**
 * Task de checagem da Lista de Certificados Revogados.
 * Essa task mant�m um arquivo local atualizado com uma
 * determinada frequ�ncia.
 *  
 * @author Egon
 *
 */
public class CRLCheckTask implements ActionListener {
	
	private static final String NM_ARQ_LISTA_REVOGADOS = "listarevogados.ser";//serializada  
	private static final String NM_ARQ_URL = "url.txt";  
	private static CRC32 CRC = new CRC32();
	private static JDKX509CertificateFactory CERT_FACTORY =  new JDKX509CertificateFactory();
	
	private File diretorioLocalCRL;

	
	/**
	 * Atualiza esse diretorio com a LCR.
	 * @param diretorioLocalCRL
	 */
	public CRLCheckTask(File diretorioLocalCRL) {
		super();
		this.diretorioLocalCRL = diretorioLocalCRL;
	}


	

	
	/**
	 * Obtem os diretorios contendo as crls para as CAs.
	 * @param diretorioLocalCRL
	 * @return
	 */
	private synchronized static ArrayList getIssuerList(File diretorioLocalCRL){
		
		ArrayList lsIssuer = new ArrayList();

		File lsDir[] = diretorioLocalCRL.listFiles();
		
		//lista pode vir nula
		if(lsDir != null){
			
			for (int i = 0; i < lsDir.length; i++) {
				
				//tem que ser um numero valido
				try{
					Long.parseLong(lsDir[i].getName());
					lsIssuer.add(lsDir[i]);
				}catch (Exception e) {
				}
			}
		}
		
		return lsIssuer;
	}
	
	
	/**
	 * Le a url a partir de um arquivo.
	 * @param arq
	 * @return
	 * @throws IOException
	 */
	private static String getUrlFromFile(File arq) throws IOException {
		
		FileInputStream fis = new FileInputStream(arq);
		try {
			
			byte[] dados = new byte[(int)arq.length()];
			fis.read(dados);
			return new String(dados, "ISO-8859-1");
			
		} finally {
			try {
				fis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Grava url em arquivo arquivo.
	 * @param arq
	 * @param url
	 * @return
	 * @throws IOException
	 */
	private static void setUrlToFile(File arq, String url) throws IOException {
		
		//cria arquivo
		if(!arq.exists()){
			try{
				if(arq.createNewFile()){
					System.out.println("Arquivo de controle de CRL criado: " + arq.getCanonicalPath());
				}
			}catch(Exception e){
				throw new IOException("N�o foi poss�vel criar arquivo de controle de CRL: " + arq.getCanonicalPath() + " (" +e.getMessage()+")");
			}
		}
		
		FileOutputStream fos = new FileOutputStream(arq);
		try {
			
			fos.write(url.getBytes("ISO-8859-1"));
			fos.flush();
			
		} finally {
			try {
				fos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	
	/**
	 * Obtem a lista de CRL a partir do diretorio especificado.
	 * @param dirCrl
	 * @param issuer
	 * @return
	 * @throws IOException 
	 */
	public synchronized static HashMap getCRL(File dirCrl, byte[] issuer) throws IOException {
		
		String issuerDir = convertIssuerToDirName(issuer);
		File crlFile = getArqListaRevogados(dirCrl, issuerDir);
		
		//deserializa lista
		if(crlFile.exists() && crlFile.length() > 0){
			
			FileInputStream fis = new FileInputStream(crlFile);
			
			try{
				
				ObjectInputStream ois = new ObjectInputStream(fis);
				return (HashMap)ois.readObject();
			}catch (ClassNotFoundException e) {
				//nao acontece
				e.printStackTrace();
			}finally{
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}
	
	private static File getArqListaRevogados(File dirCrl, String issuerDir){
		
		File dirIssuerCRL = new File(dirCrl, issuerDir);
		
		//verifica se existe diretorio
		if(!dirIssuerCRL.exists() && !dirIssuerCRL.mkdirs()){

			try{
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + dirIssuerCRL.getCanonicalPath());
			}catch(IOException e){
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + dirIssuerCRL);
				e.printStackTrace();
			}
		}
		
		return new File(dirIssuerCRL, NM_ARQ_LISTA_REVOGADOS);
	}

	
	/**
	 * Obtem a lista de crl a partir de um url.
	 * @param dirCrl
	 * @param issuer
	 * @param url
	 * @return
	 * @throws IOException 
	 */
	public synchronized static HashMap getCRLFromURL(File dirCrl, byte[] issuer, String urlCrl) throws Exception{

		return getCRLFromURL(dirCrl, convertIssuerToDirName(issuer), urlCrl);
	}
	
	/**
	 * Obtem a lista de crl a partir de um url.
	 * @param dirCrl
	 * @param issuer
	 * @param url
	 * @return
	 * @throws IOException 
	 */
	public synchronized static HashMap getCRLFromURL(File dirCrl, String issuerDir, String urlCrl) throws Exception{

		File issuerDirFile = new File(dirCrl, issuerDir); 
		
		//verifica se o diretorio existe
		if(!issuerDirFile.exists() && !issuerDirFile.mkdirs()){
			try{
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + issuerDirFile.getCanonicalPath());
			}catch(IOException ex){
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + issuerDirFile);
				ex.printStackTrace();
			}
		}
		
		
		//armazena url
		setUrlToFile(new File(issuerDirFile, NM_ARQ_URL), urlCrl);
		
		
		//tenta instanciar uma url
		URL url;
		try{			
			url = new URL(urlCrl);
		}catch(Exception ex){
			throw new Exception("URL invalida: " + urlCrl);
		}
	
		//tenta ler a partir da URL
		InputStream inCRL;
		try{
			inCRL = url.openStream();
		}catch(Exception ex){
			throw new Exception("Erro ao conectar com a url: " + ex.getMessage());
		}
			
		HashMap lista;
		try{
			lista = lerCRL(inCRL); 
		}catch(Exception ex){
			throw new Exception("Erro tentar baixar o CRL: " + ex.getMessage());
		}finally{
			try {
				inCRL.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		//serializa lista
		try {
			FileOutputStream fos = new FileOutputStream(new File(issuerDirFile, NM_ARQ_LISTA_REVOGADOS));
			
			try{
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				oos.writeObject(lista);
				oos.flush();
			}finally{
				try {
					fos.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			System.err.println("Erro ao serializar CRL: " + e.getMessage());
			e.printStackTrace();
		}
		
		return lista;
	}
	
	
	/**
	 * Le CRL a partir de uma stream.
	 * @param inCrl
	 * @return
	 * @throws Exception
	 */
	private static HashMap lerCRL(InputStream inCrl) throws Exception {

		HashMap retCRL = new HashMap();
		
		//recupera campos do CRL	
		X509CRLObject crl = null;
		try {
			//este metodo usa bufferedInputStream
			crl = (X509CRLObject) CERT_FACTORY.engineGenerateCRL(inCrl);
		} catch (Exception e) {
			throw new Exception("Erro ao fazer o parsing do CRL: " + e.getMessage());
		}

		//carrega os dados do crl
		try {

			//Date dtNextPub = crl.getNextUpdate();
			//Date dtPubAtu = crl.getThisUpdate();
			Set lsCrl = crl.getRevokedCertificates();

			Iterator lsCrlIt = lsCrl.iterator();
			X509CRLEntryObject certRev;

			while (lsCrlIt.hasNext()) {
				certRev = (X509CRLEntryObject) lsCrlIt.next();
				retCRL.put(certRev.getRevocationDate(), certRev.getSerialNumber());				
			}

		} catch (Exception e) {
			throw new Exception("Erro ao tentar recuperar os campos do CRL: " + e.getMessage());
		}

		return retCRL;
	}
	
	
	

	/**
	 * Substitui caracteres que poderiam dar problema no sistema de arquivo.
	 * @param issuer
	 * @return
	 */
	private static String convertIssuerToDirName(byte[] issuer){
	
		//substitui caracteres que poderiam dar problema no sistema de arquivo
		CRC.reset();
		CRC.update(issuer);
	
		return Long.toString(CRC.getValue());
	}

	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		
		
		//verifica se o diretorio existe
		if(!diretorioLocalCRL.exists() && !diretorioLocalCRL.mkdirs()){
			try{
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + diretorioLocalCRL.getCanonicalPath());
			}catch(IOException ex){
				System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + diretorioLocalCRL);
				ex.printStackTrace();
			}
		}
		
	    
	    //obtem a lista de issuers
	    ArrayList lsIssuerDir = getIssuerList(diretorioLocalCRL);
	    File dirIssuer;
	    String urlCrl; 
	    File arqUrl;
	    
	    for (int i = 0; i < lsIssuerDir.size(); i++) {
	    
	            //obtem a nova lista
	            try {
	                    dirIssuer = (File) lsIssuerDir.get(i);
	                    arqUrl = new File(dirIssuer, NM_ARQ_URL);
	                    
	                    //verifica se tem url cadastrada para atualizar
	                    if(arqUrl.exists()){

	                            //obtem e serializa a lista de crl
	                            urlCrl = getUrlFromFile(arqUrl);
	                            getCRLFromURL(dirIssuer.getParentFile(), dirIssuer.getName(), urlCrl);
	                            
	                            //ok
	                            System.out.println("CRL '" + urlCrl + "' atualizada (" + arqUrl.getCanonicalPath() + "): " + new java.util.Date());
	                    }
	                    
	            } catch (Exception ex) {
	                    ex.printStackTrace();
	            }
	    }
	}

}
