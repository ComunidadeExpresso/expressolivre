package br.com.nct.autenticadorssl;

import java.security.Security;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import br.com.nct.autenticadorssl.crlutils.CRLManager;

public class AutenticadorContextListener implements ServletContextListener {

	private static final String RHDS_USAR_BINDING_SSL = "RHDS_USARSSL";
	private static final String RHDS_BINDING_SSL_TRUSTSTORE = "RHDS_BINDING_SSL_TRUSTSTORE";
	private static final String RHDS_BINDING_SSL_TRUSTSTORE_PASSWORD = "RHDS_BINDING_SSL_TRUSTSTORE_PASSWORD";

	
	public void contextDestroyed(ServletContextEvent arg0) {

		//interrompe a task de atualizacao de CRLs
		CRLManager.stopUpdateTask();
	
	}

	public void contextInitialized(ServletContextEvent evt) {
		
		//adiciona security provider
		if(Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null){
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		}

		//evt.getServletContext().log("Parametro: " + evt.getServletContext().getInitParameter("CRL_DIRETORIO"));
		
		
		
		//inicia a task de atualizacao de CRLs
		int tempoMin = 5;
		String tempoMinStr = evt.getServletContext().getInitParameter("CRL_ATUALIZACAO_MIN");
		try {
			tempoMin = Integer.parseInt(tempoMinStr);
		} catch (Exception e) {
			
		}
		CRLManager.startUpdateTask(evt.getServletContext().getInitParameter("CRL_DIRETORIO"), tempoMin);

		
		//verifica se deve rodar em modo de teste - MODO_TESTE
		String modoTeste = evt.getServletContext().getInitParameter("MODO_TESTE");
		if(modoTeste != null){
			try {
				boolean modoTesteEnable = (modoTeste.equals("1") || Boolean.valueOf(modoTeste).booleanValue());
				AutenticadorServlet.MODO_AUTH_LDAP = !modoTesteEnable;
			} catch (Exception e) {}
		}
		
		//binding SSL, trustore
		String usarBindingSSL = evt.getServletContext().getInitParameter(RHDS_USAR_BINDING_SSL);
		
		if(usarBindingSSL != null 
				&& ((usarBindingSSL = usarBindingSSL.trim()).length() > 0) 
				&& (usarBindingSSL.equalsIgnoreCase("true") || usarBindingSSL.equals("1")) ){
			
			String bindingTS = evt.getServletContext().getInitParameter(RHDS_BINDING_SSL_TRUSTSTORE); 
			
			//verifica se vai o usar o truststore default (/<jre>/security/cacerts)
			if(bindingTS != null && bindingTS.length() > 0)
			{
				System.setProperty("javax.net.ssl.trustStore", bindingTS);
				System.setProperty("javax.net.ssl.trustStorePassword", evt.getServletContext().getInitParameter(RHDS_BINDING_SSL_TRUSTSTORE_PASSWORD));
			}
		}
		
	}

}
