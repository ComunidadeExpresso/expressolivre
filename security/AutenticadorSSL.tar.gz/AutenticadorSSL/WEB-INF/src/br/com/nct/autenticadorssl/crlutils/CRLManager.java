package br.com.nct.autenticadorssl.crlutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;

import org.bouncycastle.jce.provider.X509CertificateObject;

import br.com.nct.autenticadorssl.certutils.CertUtil;

public class CRLManager {
	
	private static javax.swing.Timer TIMER;
	private static File CRL_DIR;


    private static X509CertificateObject getCertTeste(){

		String nmArq = "crlteste\\gerson.cer";//"C:\\nct\\serpro\\login_kde-modulo-pam\\bb\\getcrl\\20030926a\\accertsrf.cer";
		
		try {
			
			FileInputStream fis = new FileInputStream(nmArq);
			try{
				return CertUtil.getInstanceCertificadoX509(fis);
			}finally{
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			return null;
		}
	}
	
	/**
	 * Verifica se o certificado jah foi revogado.
	 * @param cert
	 * @throws Exception
	 */
	public static void validarCertificado(java.security.cert.X509Certificate cert) throws Exception{
		
		
		/*
		//teste
		CRL_DIR = new File("C:\\nct\\eclipse\\workspace-serpro\\AutenticadorSSL\\crlteste");
		X509CertificateObject certObjTeste = getCertTeste();
		String urlTeste = "file:///nct/serpro/login_kde-modulo-pam/bb/getcrl/20030926a/LatestCRL.crl";
		validarCertificado(certObjTeste.getIssuerX500Principal().getEncoded(), 
				certObjTeste.getSerialNumber(), 
				urlTeste);
		
		HashMap otherNames = CertUtil.extrairOtherName(certObjTeste, false);
		String cpf = CertUtil.extrairCPFCertICPBR(otherNames, true);
		System.out.println(cpf);
		ArrayList lsDistPointTeste = CertUtil.extrairCRLDistributionPoint(certObjTeste, false);
		if(lsDistPointTeste.size() < 1){
			throw new Exception("Nenhum ponto de distribui��o de LCR foi definido para este certificado.");
		}
		//fim teste
		*/
		
		//recupera distributionPoints
		X509CertificateObject certObj = CertUtil.getInstanceCertificadoX509(cert);
		ArrayList lsDistPoint = CertUtil.extrairCRLDistributionPoint(certObj, false);
		if(lsDistPoint.size() < 1){
			throw new Exception("Nenhum ponto de distribui��o de LCR foi definido no seu certificado.");
		}
		
		//valida certificado
		String url = (String) lsDistPoint.get(0);
		validarCertificado(certObj.getIssuerX500Principal().getEncoded(), 
				cert.getSerialNumber(), 
				url);
		

	}
	
	
	

	/**
	 * @param serialNumber
	 * @param url
	 * @throws Exception
	 */
	public static void validarCertificado(byte[] issuer, BigInteger serialNumber, String url) throws Exception{
	
		//obtem a lista
		HashMap crl = CRLCheckTask.getCRL(CRL_DIR, issuer);
		if(crl == null){
			crl = CRLCheckTask.getCRLFromURL(CRL_DIR, issuer, url);//le e faz cache
		}
		
		//verifica se obteve crl
		if(crl != null){
			if(crl.containsValue(serialNumber)){
				throw new Exception("Certificado revogado. Acesso negado.");
			}
		}else{
			throw new Exception("N�o foi possivel verificar a validade do certificado");
		}
	}

	
	
	
	/**
	 * Inicia a task de atualizacao de CRLs. 
	 */
	public synchronized static void startUpdateTask(String crlDir, int minUpdateFrequency){
		
		//cria diretorio base
		CRL_DIR = new File(crlDir);
		if(!CRL_DIR.exists()){
			if(!CRL_DIR.mkdirs()){
				try{
					System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + CRL_DIR.getCanonicalPath());
				}catch(IOException e){
					System.out.println("N�o foi poss�vel criar o diret�rio de cache da LCR: " + crlDir);
					e.printStackTrace();
				}
			}
		}		
		
		//inicia task
		//javax.swing.Timer timer = new javax.swing.Timer(minUpdateFrequency * 1000, new CRLCheckTask(CRL_DIR));
		javax.swing.Timer timer = new javax.swing.Timer(minUpdateFrequency * 60000, new CRLCheckTask(CRL_DIR));
		timer.setRepeats(true);
		timer.setInitialDelay(0);
		timer.start();
		TIMER = timer;
	}

	/**
	 * Interrompe a task de atualizacao de CRLs. 
	 */
	public synchronized static void stopUpdateTask(){
		
		if(TIMER != null){
			TIMER.stop();
			TIMER = null;
		}
	}
}
