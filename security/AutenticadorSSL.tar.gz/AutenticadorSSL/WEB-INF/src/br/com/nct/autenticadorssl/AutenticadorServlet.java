package br.com.nct.autenticadorssl;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.security.Provider;
import java.security.Security;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import netscape.ldap.LDAPException;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.provider.X509CertificateObject;
import org.bouncycastle.util.encoders.Base64;

import br.com.nct.autenticadorssl.certutils.CertUtil;
import br.com.nct.autenticadorssl.crlutils.CRLManager;
import br.com.nct.autenticadorssl.ldaputils.Binding;
import br.com.nct.autenticadorssl.ldaputils.LDAPSearchUtil;

public class AutenticadorServlet extends HttpServlet {

	
	private static final String RHDS_CONN_TIMEOUT = "RHDS_CONN_TIMEOUT";
	private static final String RHDS_USERPASSWORD = "RHDS_USERPASSWORD";
	private static final String RHDS_USERDN = "RHDS_USERDN";
	private static final String RHDS_HOST = "RHDS_HOST";
	private static final String RHDS_SEARCH_FILTER = "RHDS_SEARCH_FILTER";
	private static final String RHDS_SEARCH_BASE_DN = "RHDS_SEARCH_BASE_DN";
	private static final String RHDS_USAR_BINDING_SSL = "RHDS_USARSSL";
	
	static boolean MODO_AUTH_LDAP = true;

	
    private Binding ldapBinding;

    public AutenticadorServlet() {
	}

	
	
	//@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	//@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(MODO_AUTH_LDAP){
			autenticarUsuario(request, response);
		}else{
			autenticarUsuarioTeste(request, response);
		}
	}

	
	/**
	 * Obtem o certificado do cliente que abriu a conexao SSL.
	 * @param request
	 * @return
	 */
	private static java.security.cert.X509Certificate getPeerCertificate(HttpServletRequest request){

		//System.out.println(request.getAttribute("javax.servlet.request.X509Certificate"));
		//System.out.println((String)request.getAttribute("javax.servlet.request.cipher_suite"));

		Object obj = request.getAttribute("javax.servlet.request.X509Certificate");
		java.security.cert.X509Certificate[] certs = (java.security.cert.X509Certificate[])obj;//request.getAttribute("javax.servlet.request.X509Certificate"); 

		if(certs != null){
			return certs[0];
		}else{
			return null;
		}
	}

	/**
	 * @param request
	 * @return
	 */
	private String getID(java.security.cert.X509Certificate cert){
		
		if(cert != null){

			sun.security.x509.X500Name name = (sun.security.x509.X500Name)cert.getSubjectDN();
	
			try {
				return name.getCommonName();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			//return cert.getSubjectDN().getName();
		}else{
			System.out.println("ERRO: Certificado NULO. Nao eh uma conexao SSL. Requisicao recusada.");
			return null;
		}
	}	
	
	private String getValorMapeado(String arquivo, String id){
		
		System.out.println("Recuperando ID: " + id);
		
		FileInputStream fis = null;
		try{
			fis = new FileInputStream(arquivo);
			Properties props = new Properties();
			props.load(fis);
			
			if(props.containsKey(id)){
				return props.getProperty(id);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(fis != null){
				try {
					fis.close();
				} catch (Exception e2) {
				}
			}
		}
		
		return "nulo";
	}

	

	
	/**
	 * Autentica o usuario a partir de uma conexao SSL.
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void autenticarUsuario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Autenticando usuario...");
		
		//recupera o certificado do usuario
		java.security.cert.X509Certificate cert = getPeerCertificate(request);
		
		String cpf, usuario, senha;
		String retorno = null;
		String crlCritico;
		
		try {
			
			//verifica se conexao SSL
			if(cert == null){
				throw new Exception("Acesso negado: Conex�o n�o criptografada.");
			}
			
			//valida certificado
			try {
				CRLManager.validarCertificado(cert);
			} catch (Exception e) {
				
				//trace para o log
				e.printStackTrace();
				
				//se critico lan�a exception - CRL_CRITICO
				crlCritico = this.getInitParameter("CRL_CRITICO");
				
				if(crlCritico != null && ( (crlCritico = crlCritico.trim().toLowerCase()).equals("true") || crlCritico.equals("1"))){
					//repassa apenas a mensagem para o usuario
					throw new Exception(e.getMessage());
				}
			}

			//recupera cpf
			try {
				X509CertificateObject certObj = CertUtil.getInstanceCertificadoX509(cert);
				HashMap otherName = CertUtil.extrairOtherName(certObj, false);
				cpf = CertUtil.extrairCPFCertICPBR(otherName, true);
				if(cpf == null){
					throw new Exception("Campo CPF inexistente na extens�o OtherName do certificado.");
				}
				
			} catch (Exception e) {
				throw new Exception("Erro ao extrair CPF do certificado: " + e.getMessage());
			}

			//conecta no ldap
			try {
				ldapBinding = new Binding(getServletContext().getInitParameter(RHDS_HOST),
						getServletContext().getInitParameter(RHDS_USERDN),
						getServletContext().getInitParameter(RHDS_USERPASSWORD),
						getServletContext().getInitParameter(RHDS_CONN_TIMEOUT),
						getServletContext().getInitParameter(RHDS_USAR_BINDING_SSL));
				ldapBinding.conectar();
				
			} catch (Exception e) {
				throw new Exception("Erro ao conectar no servidor: " + e.getMessage());
			}

			//recupera usuario no ldap
			HashMap dadosUsuario;
			Object userCertificate;
			byte[] userCertificateDer;
			boolean isDerEncoded;
			String userCertificateStr;
			String searchBaseDN;
			String searchFilter;
			int i;
			char[] certCharArray;
			byte[] dados;
			
			try {
				searchBaseDN = this.getServletContext().getInitParameter(RHDS_SEARCH_BASE_DN);
				searchFilter = this.getServletContext().getInitParameter(RHDS_SEARCH_FILTER);
				dadosUsuario = LDAPSearchUtil.getDadosUsuario(ldapBinding.getLDAPConnection(), searchBaseDN, searchFilter, cpf);
				
				if(dadosUsuario != null){
					usuario = (String) dadosUsuario.get(LDAPSearchUtil.CAMPO_USUARIO);
					senha = (String) dadosUsuario.get(LDAPSearchUtil.CAMPO_SENHA);
					userCertificate = dadosUsuario.get(LDAPSearchUtil.CAMPO_CERTIFICADO);
					
					//verifica usu�rio
					if(usuario == null || (usuario = usuario.trim()).length() == 0){
						throw new Exception("Usu�rio n�o encontrado no servidor.");						
					}
					
					//verifica certificado
					if(userCertificate == null){
						throw new Exception("Certificado n�o cadastrado no servidor.");						
					}else{
						
						//verifica se os dois certificados s�o iguais
						try{
							userCertificateDer = CertUtil.getInstanceCertificadoX509(new ByteArrayInputStream((byte[])userCertificate)).getEncoded();
						}catch (Exception e) {
							System.out.println("N�o foi poss�vel validar o certificado cadastrado no servidor: " + e.getClass().getName());
							e.printStackTrace();
							throw new Exception("N�o foi poss�vel validar o certificado cadastrado no servidor. Contacte o suporte.");						
						}
							
						//compara certificados
						if(!Arrays.equals(userCertificateDer, cert.getEncoded())){
							throw new Exception("Certificado cadastrado no servidor diferente do utilizado na conex�o.");
						}
					}
					
					//verifica senha
					if(senha == null  || (senha = senha.trim()).length() == 0){
						throw new Exception("Senha n�o cadastrada no servidor.");						
					}
					
				}else{
					throw new Exception("Dados do usu�rio n�o encontrados no servidor.");
				}
				
			 } catch ( LDAPException ex ) {
				 
				 ex.printStackTrace();
				 String msg = ex.getLDAPErrorMessage();
			     
				 switch( ex.getLDAPResultCode() ) {
			         case LDAPException.NO_SUCH_OBJECT:
			             msg = "Usu�rio n�o cadastrado no servidor.";
			             break;
			         case LDAPException.LDAP_PARTIAL_RESULTS:
			             msg = "O usu�rio est� em um servidor diferente (referral).";
			             break;
			         case LDAPException.INSUFFICIENT_ACCESS_RIGHTS:
			             msg = "O autenticador est� sem acesso aos atributos de busca.";
			             break;
			         default:
			             msg += " CodErro: " + ex.getLDAPResultCode();
			             break;
			     }
				 
				throw new Exception("Erro ao recuperar dados do servidor: " + msg);

			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Erro ao recuperar dados do servidor: " + e.getMessage());
			}
			
			//monta retorno
			StringBuffer sb = new StringBuffer();
			sb.append("<senha>");
			sb.append(senha);
			sb.append("<usuario>");
			sb.append(usuario);
			retorno = sb.toString();

		} catch (Exception e) {
			//e.printStackTrace();
			retorno = "<erro>" + e.getMessage();
			
			//exibe erro na console
			System.out.println("Falha na autenticacao: " + e.getClass().getName() + " - " + e.getMessage());
			e.printStackTrace();
			
		}finally{
			
			//fecha conexao ldap
			if(ldapBinding != null){
				try {
					ldapBinding.desconectar();
				} catch (Exception e) {
					//ignora
					e.printStackTrace();
				}
			}
		}
		
		//grava retorno
		OutputStream out = response.getOutputStream();
		out.write(retorno.getBytes("UTF-8"));//"ISO-8859-1"));//"UTF-8"));
		out.close();

		System.out.println("Fim autenticacao.");
	}	

	
	
	private void autenticarUsuarioTeste(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Autenticando usuario...");

		//tenta descobrir o certificado
		String arquivo = getInitParameter("MAPEAMENTO");
		java.security.cert.X509Certificate cert = getPeerCertificate(request);
		String id  = getID(cert);
		String usuario = getValorMapeado(arquivo, id);
		String senha = getValorMapeado(arquivo, "senha." + id);

		

		//dados
		String retorno = null;
		StringBuffer sb = new StringBuffer();
		
		if(request.getRequestURI().endsWith("senhaemclaro")){
			sb.append("<senha>");
			sb.append(senha);
			sb.append("<usuario>");
			sb.append(usuario);
			retorno = sb.toString();
		}else{
			byte dados[] = senha.getBytes("ISO-8859-1");
			
			
			try {
				
				//teste
				//Provider prov = Security.getProvider(BouncyCastleProvider.PROVIDER_NAME);
				//Iterator iterator = prov.getServices().iterator();
				//while (iterator.hasNext()) {
				//	System.out.println(iterator.next());					
				//}
				
				//codificacao MD5withRSA
				String tipoPad="RSA/ECB/PKCS1Padding";
				Cipher rsaCipher = Cipher.getInstance(tipoPad, BouncyCastleProvider.PROVIDER_NAME); 
				// NoPadding = 117 bytes

				//cifrar
				rsaCipher.init(Cipher.ENCRYPT_MODE, cert.getPublicKey());
				byte[] dadosCifrados = rsaCipher.doFinal(dados);
				
				sb.append("<senha>");
				//codifica base64
				sb.append(new String(Base64.encode(dadosCifrados), "ISO-8859-1"));
				//sb.append(new Base64Encoder(new String(dadosCifrados, "ISO-8859-1")).processString());
				sb.append("<usuario>");
				sb.append(usuario);
				retorno = sb.toString(); 

			}catch (Exception e) {
				e.printStackTrace();
				retorno = e.getMessage();
			}
		}

		PrintWriter pw = response.getWriter();
		pw.write(retorno);
		pw.close();


		//https://localhost:8443/autenticador/senha/getsenhaemclaro
		System.out.println("Fim autenticacao.");
	}

}
