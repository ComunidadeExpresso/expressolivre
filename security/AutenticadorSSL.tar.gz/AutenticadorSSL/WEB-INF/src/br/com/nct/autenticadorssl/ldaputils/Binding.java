package br.com.nct.autenticadorssl.ldaputils;


import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPException;
import netscape.ldap.factory.JSSESocketFactory;


/**
 * Binding RHDS.
 * 
 * Trustore:
 * java -Djavax.net.ssl.trustStore=truststore -Djavax.net.ssl.trustStorePassword=123456 MyApp
 * 
 * Extraido do http://docs.sun.com/source/816-6402-10/
 * @author Egon
 *
 */
public class Binding {
	
	private String host;
	private String userdn;
	private String userpassword;
	private LDAPConnection ld;
	private JSSESocketFactory ssl;
	//private LDAPSSLSocketFactory ssl;
	private int port;
	private int timeoutSecs;


	/**
	 * Obtem a conexao.
	 * @return
	 */
	public LDAPConnection getLDAPConnection() {
		return ld;
	}

	

	/**
	 * @param servlet
	 */
	public Binding(String host, String userDN, String userPassword, String connTimeout, String usarSSL){
		this(host, userDN, userPassword, 
				converterTimeout(connTimeout),
				converterBoolean(usarSSL));
	}

	
	/**
	 * Cria instancia.
	 * @param host
	 * @param userdn
	 * @param userpassword
	 * @param usarSSL
	 */
	public Binding(String host, String userdn, String userpassword, int timeoutSecs, boolean usarSSL)
	{
		this.host = host;
		this.userdn = userdn;
		this.userpassword  = userpassword;
		this.timeoutSecs = timeoutSecs;
		if(usarSSL){
			this.ssl = new JSSESocketFactory();//LDAPSSLSocketFactory();
			this.ld = new LDAPConnection(this.ssl);
			this.port = 636;
		}else{
			this.ld = new LDAPConnection();
			this.port = 389;
		}
	}


	/**
	 * Conectar. 
	 */
	public void conectar() throws LDAPException
	{
		ld.setConnectTimeout(timeoutSecs);
		
		//login anonimo
		//ld.connect(host, port);
		
		//login
		ld.connect(host, port, userdn, userpassword);
	}
	
	/**
	 * Desconectar.
	 * @throws LDAPException
	 */
	public void desconectar() throws LDAPException {

	   if ((ld != null) && ld.isConnected()){
	         ld.disconnect();
	   }
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString ()
	{
	   String str = null;

	   str = "\n" + "host          : " + this.host          + "\n" +
	                "userdn        : " + this.userdn        + "\n" +
	                "userpassword  : " + this.userpassword  + "\n" +
	   				"port          : " + this.port  + "\n";
	   return(str);
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {

		try {
			desconectar();
		} catch (Exception e) {
		}
		
		super.finalize();
	}


	/**
	 * Converte para boolean.
	 * @param tx
	 * @return
	 */
	private static boolean converterBoolean(String tx){
		
		if(tx != null){
			if(tx.trim().toLowerCase().equals("true")){
				return true;
			}			
		}
		return false;
	}
	
	/**
	 * Obtem o timeout da conexao.
	 * @param tx
	 * @return
	 */
	private static int converterTimeout(String tx){
		
		if(tx != null){
			tx = tx.trim();
			
			try {
				return Integer.parseInt(tx);
			} catch (Exception e) {
			}
		}
		return 10;//segundos
	}
	

}



