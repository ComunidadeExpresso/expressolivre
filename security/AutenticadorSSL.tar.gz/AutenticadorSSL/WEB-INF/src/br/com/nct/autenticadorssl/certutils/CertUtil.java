package br.com.nct.autenticadorssl.certutils;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERConstructedSequence;
import org.bouncycastle.asn1.DERInputStream;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUnknownTag;
import org.bouncycastle.asn1.x509.CRLDistPoint;
import org.bouncycastle.asn1.x509.DistributionPoint;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.jce.provider.JDKX509CertificateFactory;
import org.bouncycastle.jce.provider.X509CertificateObject;


public class CertUtil {

	private static final String SUBJECT_ALTERNATIVE_NAME = "2.5.29.17";
	private static final String CRL_DISTRIBUTION_POINT = "2.5.29.31";

	
   	private static JDKX509CertificateFactory 	CERT_FACTORY = null;
  	private static boolean init = false;

   	private CertUtil() {
	}

	/**
	 * Extrai o ponto de distribuicao(URL) de CRL para este certificado.
	 * @param cert
	 * @param isCritical
	 * @return
	 * @throws java.io.IOException
	 */
	public static ArrayList extrairCRLDistributionPoint(X509CertificateObject cert, boolean isCritical) throws java.io.IOException{

		ArrayList ret = new ArrayList();
		Set extension=null;
		if(isCritical){
			extension=cert.getCriticalExtensionOIDs();
		}else{
			extension=cert.getNonCriticalExtensionOIDs();
		}
		
		//String CRL_DISTRIBUTION_POINT = "2.5.29.31";
		
		ByteArrayInputStream bis=null;
		DERInputStream dis=null;
		ASN1OctetString os=null;
		DERObject dObj=null;
		ASN1Sequence seqObj=null;
		DERTaggedObject tagObj=null;
		ASN1Sequence generalName=null;
		DERObjectIdentifier    gn_oid=null;
		DERTaggedObject        gn_taggedobj=null;
		String oidStr  =null;
		String valorStr=null;
		
		if(extension != null){
			if(!extension.isEmpty()){
				Iterator it=extension.iterator();
				while(it.hasNext()){
					String oidExt=(String)it.next();
					if(!oidExt.equals(CRL_DISTRIBUTION_POINT)){ //testa se crlDistributionPoint
						continue;
					}
					byte dados[]=cert.getExtensionValue(oidExt);
					bis=new ByteArrayInputStream(dados);
					dis=new org.bouncycastle.asn1.DERInputStream(bis);
					dObj=dis.readObject();
					if( !(dObj instanceof DEROctetString) ){
						continue;
					}
					os=(DEROctetString)dObj;

					dis.reset();
					dados=os.getOctets();
					bis=new ByteArrayInputStream(dados);
					dis=new DERInputStream(bis);
					dObj=dis.readObject();
					if( !(dObj instanceof ASN1Sequence) ){
						continue;
					}
					seqObj=(ASN1Sequence)dObj;
					
					
					CRLDistPoint distPoint = new CRLDistPoint(seqObj);
					DistributionPoint disPoints[] = distPoint.getDistributionPoints();
					for (int i = 0; i < disPoints.length; i++) {
						
						/* le generalName */
						generalName=(ASN1Sequence)disPoints[i].getDistributionPoint().getName().getDERObject();
						if(!(generalName.getObjectAt(0) instanceof DERTaggedObject)){
							continue;
						}

						/* obtem os valores do generalName */
						gn_taggedobj=(DERTaggedObject)generalName.getObjectAt(0);
						
						dObj=gn_taggedobj.getObject();
						if(dObj instanceof DERString){
							valorStr=((DERString)dObj).getString();
						}else if(dObj instanceof DEROctetString){
							valorStr=new String( ((DEROctetString)dObj).getOctets(), "ISO-8859-1");
						}else if(dObj instanceof DERUnknownTag){
							valorStr=new String( ((DERUnknownTag)dObj).getData(), "ISO-8859-1");
						}else{
							continue;
						}
						
						//ok
						ret.add(valorStr);
					}//for
				}
			}
		}
		return ret;
	}	
	
	
	/**
	 * @param otherNames
	 * @param pessoaFisica
	 * @return Retorna nulo se nao possui campo.
	 */
	public static String extrairCPFCertICPBR(HashMap otherNames, boolean pessoaFisica){
		
		String oid = pessoaFisica ? "2.16.76.1.3.1" : "2.16.76.1.3.4";
		
		if(otherNames != null && otherNames.containsKey(oid)){
			String cpf = (String)otherNames.get(oid);
			if(cpf != null && cpf.length() >= 18){
				return cpf.substring(8, 19);
			}
		}

		return null;
	}
	
	/**
	 * Extrai os campos otherName de uma extensao do tipo subjectAlternatineName.
	 * @return HashMap
	 * @param extension java.util.Set
	 */
	public static HashMap extrairOtherName(X509CertificateObject cert, boolean isCritical) throws java.io.IOException{

		HashMap ret = new HashMap();
		Set extension=null;
		if(isCritical){
			extension=cert.getCriticalExtensionOIDs();
		}else{
			extension=cert.getNonCriticalExtensionOIDs();
		}


		//String SUBJECT_ALTERNATIVE_NAME = "2.5.29.17";
		/*
		//String SUBJECT_ALTERNATIVE_NAME="2.5.29.15";
		///String SUBJECT_ALTERNATIVE_NAME="2.16.76.1.3.1";
		 */

		ByteArrayInputStream bis=null;
		DERInputStream dis=null;
		ASN1OctetString os=null;
		DERObject dObj=null;
		ASN1Sequence seqObj=null;
		DERTaggedObject tagObj=null;
		ASN1Sequence generalName=null;
		DERObjectIdentifier    gn_oid=null;
		DERTaggedObject        gn_taggedobj=null;
		String oidStr  =null;
		String valorStr=null;
		
		if(extension != null){
			if(!extension.isEmpty()){
				Iterator it=extension.iterator();
				while(it.hasNext()){
					String oidExt=(String)it.next();
					if(!oidExt.equals(SUBJECT_ALTERNATIVE_NAME)){ //testa se um subjectAlternativeName
						continue;
					}
					byte dados[]=cert.getExtensionValue(oidExt);
					bis=new ByteArrayInputStream(dados);
					dis=new org.bouncycastle.asn1.DERInputStream(bis);
					dObj=dis.readObject();
					if( !(dObj instanceof ASN1OctetString) ){
						continue;
					}
					os=(ASN1OctetString)dObj;

					dis.reset();
					dados=os.getOctets();
					bis=new ByteArrayInputStream(dados);
					dis=new DERInputStream(bis);
					dObj=dis.readObject();
					if( !(dObj instanceof ASN1Sequence) ){
						continue;
					}
					seqObj=(ASN1Sequence)dObj;
					//
					//ret=new String[seqObj.size()];
					//
					for(int i=0; i<seqObj.size(); i++){
						dObj=(DERObject)seqObj.getObjectAt(i);
						if( !(dObj instanceof DERTaggedObject) ){
							continue;
						}

						tagObj=(DERTaggedObject) dObj;
						dObj=tagObj.getObject();
						if( !(dObj instanceof ASN1Sequence)){
							continue;
						}

						/* le generalName */
						generalName=(ASN1Sequence)dObj;
						if(generalName.size() !=2 ){
						}
						if(!(generalName.getObjectAt(0) instanceof DERObjectIdentifier)){
							continue;
						}
						if(!(generalName.getObjectAt(1) instanceof DERTaggedObject)){
							continue;
						}

						/* obtem os valores do generalName */
						gn_oid=(DERObjectIdentifier)generalName.getObjectAt(0);
						gn_taggedobj=(DERTaggedObject)generalName.getObjectAt(1);
						
						dObj=gn_taggedobj.getObject();
						if(dObj instanceof DERString){
							valorStr=((DERString)dObj).getString();
						}else if(dObj instanceof DEROctetString){
							valorStr=new String( ((DEROctetString)dObj).getOctets(), "ISO-8859-1");
						}else if(dObj instanceof DERUnknownTag){
							valorStr=new String( ((DERUnknownTag)dObj).getData(), "ISO-8859-1");
						}else{
							continue;
						}
						
						oidStr=gn_oid.getId();
						//
						ret.put(oidStr, valorStr);
						//ret[i]=oidStr+"=\""+valorStr+"\"";
						//System.out.print(ret[i]);
					}

					//TODO: verificar se precisa mesmo 
					//interrompe - trata apenas uma ocorrencia do subjectAlternativeName
					break;				
				}
			}
		}
		return ret;
	}

	/**
	 * Obtem uma instancia de um certificado X509.
	 * @return org.bouncycastle.jce.provider.X509CertificateObject
	 */
	public static X509CertificateObject getInstanceCertificadoX509(java.security.cert.X509Certificate cert) throws Exception {
		
		ByteArrayInputStream bis = new ByteArrayInputStream(cert.getEncoded());		
		return getInstanceCertificadoX509(bis);
	}

	/**
	 * Obtem uma instancia de um certificado X509.
	 * @return org.bouncycastle.jce.provider.X509CertificateObject
	 */
	public static X509CertificateObject getInstanceCertificadoX509(InputStream is) throws Exception {


		initialize();
		
		X509CertificateObject cert = null;

		try{
			cert = (X509CertificateObject)CERT_FACTORY.engineGenerateCertificate(is);
			
		}catch(Exception e){
			throw e;
		}
		
		return cert;
	}


	/**
	 * Inicializa.
	 * @exception java.lang.Exception The exception description.
	 */
	private static void initialize() throws java.lang.Exception {

		if(!init){
			//provider
			java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			CERT_FACTORY= new JDKX509CertificateFactory();
			/* adiciona OIDS */
		    /* state, or province name - StringType(SIZE(1..64))  */
			final DERObjectIdentifier S = new DERObjectIdentifier("2.5.4.4");
			X509Name.OIDLookUp.put(S, "S");
			X509Name.SymbolLookUp.put("S", S);
			/* */
			init=true;
		}
	}


}
