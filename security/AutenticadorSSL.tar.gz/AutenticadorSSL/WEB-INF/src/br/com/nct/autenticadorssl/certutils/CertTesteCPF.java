package br.com.nct.autenticadorssl.certutils;

import java.io.FileInputStream;
import java.util.HashMap;

import org.bouncycastle.jce.provider.X509CertificateObject;

public class CertTesteCPF {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//recupera cpf
		try {
			String arqCer = "C:\\Documents and Settings\\Egon\\Desktop\\Serpro\\marcelo.cer";
			
			String arqCer2="C:\\nct\\serpro\\login_kde-modulo-pam\\docs-serpro\\gerson.der";
			
			FileInputStream fis = new FileInputStream(arqCer);
			X509CertificateObject certObj = CertUtil.getInstanceCertificadoX509(fis);
			HashMap otherName = CertUtil.extrairOtherName(certObj, false);
			String cpf = CertUtil.extrairCPFCertICPBR(otherName, true);
			if(cpf == null){
				throw new Exception("A extens�o OtherName/ICP-BR/PessoaFisica n�o est� presente no certificado.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

}
